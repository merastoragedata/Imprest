# Imprest Portal — Backend API (Google Apps Script + Drive)

This is a **backend only** — it doesn't serve any web page. It's a JSON API that your GitHub-hosted front-end calls over the internet. Data lives in **Google Drive**, organized as one folder per employee — no separate database to set up.

## How storage works

```
Imprest Portal Data/              <- created automatically on first use
  ashish/
    profile.json                  <- this employee's profile
    entries.json                  <- all their TI/PI records
    otherExpenses.json            <- their standalone expense pool
  priya/
    profile.json
    entries.json
    otherExpenses.json
```

Nothing to create by hand — the first time anyone registers, the script creates the root folder and their personal subfolder automatically. This also sets up nicely for later: generated letters, vouchers, and Form-2 Docs will get added into these same per-employee folders, so everything for one person lives in one place.

## Setup

1. **Create the Apps Script project.** Go to script.google.com -> New project. Rename it (e.g. "Imprest Portal API").
2. Delete the default code and paste in this folder's `Code.gs`.
3. **Change the admin password** near the top of `Code.gs`:
   ```js
   var ADMIN_PASSWORD = 'admin123'; // change this
   ```
4. Open **Project Settings** (gear icon) -> check "Show appsscript.json manifest file in editor" -> open `appsscript.json` and replace its contents with this folder's version.
5. Run the `setupInitialData` function once (select it from the function dropdown at the top, click **Run**). This creates the root Drive folder and, importantly, triggers the permission prompt — approve Drive access when asked.
6. **Deploy -> New deployment -> Web app**
   - Execute as: **Me** (this means all employee folders live under *your* Drive — matches the shared-centralized-folder plan discussed earlier, so Accounts/reporting officers can be given visibility into the same tree later)
   - Who has access: **Anyone** (needed so the GitHub-hosted front-end can reach it — every request still requires the right username/password or admin credentials, so this doesn't expose data, just makes the endpoint reachable)
7. Copy the **Web app URL** it gives you (ends in `/exec`) — you'll hand this to me for the front-end wiring.

## Testing it works, before wiring the front-end

Paste this into your browser's address bar (replace `YOUR_URL`):
```
YOUR_URL?action=adminLogin&username=admin&password=admin123
```
You should see `{"ok":true}`. Then check your Google Drive — you should see a new folder called **"Imprest Portal Data"**.

Try registering a test account too:
```
YOUR_URL?action=register&username=testuser&password=test123
```
You should see a profile object come back, and a new `testuser` subfolder appear inside "Imprest Portal Data" in your Drive.

## What this API does

| Action | Method | Purpose |
|---|---|---|
| `adminLogin` | GET/POST | Admin credential check (server-side — not visible in browser source) |
| `register` | POST | Create a pending employee account + their Drive folder |
| `login` | POST | Log in an approved employee |
| `getEmployee` / `saveEmployee` | GET / POST | Read/update a profile |
| `listEmployees` | GET | For the admin approval panel (scans every subfolder) |
| `approveEmployee` / `revokeEmployee` / `rejectEmployee` | POST | Admin actions — `rejectEmployee` trashes the whole folder |
| `listEntries` / `saveEntry` / `deleteEntry` | GET / POST | TI/PI records |
| `listOtherExpenses` / `saveOtherExpense` / `deleteOtherExpense` | GET / POST | The standalone expense pool |

## Known limitations — read before relying on this for real approvals

- **Admin actions aren't token-protected yet.** `adminLogin` correctly checks the password server-side, but `approveEmployee`/`rejectEmployee`/etc. don't currently verify a session token — anything calling the API directly (not through your app's UI) could call them. Acceptable for a closed pilot on a private URL; worth tightening before wider rollout.
- **Passwords are SHA-256 hashed**, not salted+hashed with a slow algorithm (bcrypt-style) — better than plain text, not enterprise-grade.
- **Read-modify-write locking**: every write uses `LockService` so two rapid saves for the same user can't silently overwrite each other — but it does mean writes queue up one at a time (fine for this scale of usage).
- **`getFoldersByName` searches your whole Drive**, not just this app's folder — if you happen to have another folder also literally named "Imprest Portal Data" elsewhere, rename one to avoid ambiguity.
- **No rate limiting.** Low risk for an internal MSETCL tool on an unlisted URL, but worth knowing.

## Next step

This backend works standalone right now — test it with the URL tricks above before doing anything else. `app.js` (from the GitHub package) still uses in-browser storage today — it doesn't call this API yet. Once you've confirmed the tests above work and given me the `/exec` URL, I'll wire the front-end to call this API for real.
